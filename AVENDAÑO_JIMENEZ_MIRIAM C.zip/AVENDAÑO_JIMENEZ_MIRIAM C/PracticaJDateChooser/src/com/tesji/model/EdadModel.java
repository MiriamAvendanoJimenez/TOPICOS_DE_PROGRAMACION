package com.tesji.model;

public class EdadModel {	
	public int dias;
	public int anioN;	
	
	public String calcular() {		
		int anios;
		int meses;
		int dias_1;		
		
		if(anioN%4==0) {
			dias-=1;
		}else {
			dias-=2;
		}	
		anios= (int) (dias/365.25);	
		meses=(int) ((dias-(anios*365.25))/30.417);
		dias_1=(int) ((dias-(anios*365.25))-(meses*30));
		if(dias_1>31) {
			meses+=1;
			dias_1=0;
		}
		if (dias_1==-1) {
			dias_1=0;
		}
			
		return "EDAD: \n\nAnios: "+anios+"\nMeses: "+
			meses+"\nDias: "+dias_1;		
	}
}
