package com.tesji.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;

import com.tesji.model.EdadModel;
import com.toedter.calendar.JDateChooser;

import java.awt.Label;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.TextArea;

public class EdadView extends JFrame {
	EdadModel calcular= new EdadModel();
	private JPanel contentPane;
	private Date fechaNac;
	private Date fechaAc;		

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EdadView frame = new EdadView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EdadView() {
		super("** **JDateChooser** **");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 413, 309);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(4, 1, 8));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		setResizable(false);
		
		JDateChooser dcNacimiento = new JDateChooser();
		dcNacimiento.setBounds(229, 55, 136, 20);
		contentPane.add(dcNacimiento);
		
		JDateChooser dcActual = new JDateChooser();
		dcActual.setBounds(229, 97, 136, 20);
		contentPane.add(dcActual);
		
		Label lbl = new Label("FECHA DE NACIMIENTO:");
		lbl.setFont(new Font("Dialog", Font.BOLD, 12));
		lbl.setForeground(new Color(255, 255, 255));
		lbl.setBounds(27, 53, 239, 22);
		contentPane.add(lbl);
		
		Label lbl_1 = new Label("FECHA ACTUAL:");
		lbl_1.setFont(new Font("Dialog", Font.BOLD, 12));
		lbl_1.setForeground(Color.WHITE);
		lbl_1.setBounds(27, 95, 196, 22);
		contentPane.add(lbl_1);
		
		TextArea txtResultados = new TextArea();
		txtResultados.setBounds(172, 153, 196, 98);
		contentPane.add(txtResultados);
		
		Label label = new Label("CAPTURE LA SIGUIENTE INFORMACION:");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Dialog", Font.BOLD, 12));
		label.setBackground(Color.BLACK);
		label.setBounds(97, 10, 239, 22);
		contentPane.add(label);
		
		Button btnCalcular = new Button("Calcular edad");
		btnCalcular.setFont(new Font("Dialog", Font.BOLD, 12));
		btnCalcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {										
				try {					
					calcular.anioN=dcNacimiento.getCalendar().get(Calendar.YEAR);										
					fechaNac = dcNacimiento.getDate();
					fechaAc = dcActual.getDate();	
					if(fechaNac.compareTo(fechaAc)==-1) {									
						calcular.dias=(int) ((fechaAc.getTime()-fechaNac.getTime())/(1000*60*60*24)+1);										
						txtResultados.setText(calcular.calcular());					
					}else{
						JOptionPane.showMessageDialog(rootPane, "Selecciona fechas v�lidas!");
					}
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(rootPane, "Selecciona fechas v�lidas");
				}
			}
		});
		btnCalcular.setBackground(new Color(43, 193, 255));
		btnCalcular.setBounds(26, 153, 107, 22);
		contentPane.add(btnCalcular);
		
		Button btnNuevo = new Button("Nuevo");
		btnNuevo.setFont(new Font("Dialog", Font.BOLD, 12));
		btnNuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dcNacimiento.setDate(null);
				dcNacimiento.requestFocusInWindow();
				dcActual.setDate(null);					
				txtResultados.setText(null);
			}
		});
		btnNuevo.setBackground(new Color(43, 193, 255));
		btnNuevo.setBounds(26, 192, 107, 22);
		contentPane.add(btnNuevo);
		
		Button btnSalir = new Button("Salir");
		btnSalir.setFont(new Font("Dialog", Font.BOLD, 12));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnSalir.setBackground(new Color(43, 193, 255));
		btnSalir.setBounds(26, 229, 107, 22);
		contentPane.add(btnSalir);			
		
	}
}
