package com.tesji.main;

import com.tesji.view.EdadView;

public class EdadMain {
	public static void main(String[]args) {
		new EdadView().setVisible(true);
	}
}
